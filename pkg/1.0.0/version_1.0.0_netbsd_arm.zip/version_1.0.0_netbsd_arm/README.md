# version
CLI command to verify versions and version constraints 
